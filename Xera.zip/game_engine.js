/* ==========================================================================
   XERA GAME ENGINE & EXECUTOR RUNTIME (game_engine.js)
   Zentraler Game-Runner & State Management für XERA
   ========================================================================== */

const XeraEngine = {
    config: {
        appName: "XERA Gaming Hub",
        version: "1.0.0",
        defaultTokens: 5000000000000
    },

    activeBlobURLs: [],

    init() {
        console.log(`[XERA Engine v${this.config.version}] System gestartet.`);
        this.injectGameViewportModal();
    },

    // Injectet das große Spiele-Fenster (Modal/Overlay) dynamisch in das DOM
    injectGameViewportModal() {
        if (document.getElementById('xera-game-modal')) return;

        const modalHTML = `
            <div id="xera-game-modal" class="xera-game-modal" style="display: none;">
                <div class="xera-game-header">
                    <div class="game-info">
                        <span class="logo-icon">⚡</span>
                        <h3 id="xera-game-title">XERA Game Instance</h3>
                    </div>
                    <div class="game-controls">
                        <button id="xera-btn-fullscreen" class="btn-glow btn-small">🛈 Vollbild</button>
                        <button id="xera-btn-close" class="btn-danger btn-small">❌ Spiel Beenden</button>
                    </div>
                </div>
                <div class="xera-game-body">
                    <iframe id="xera-game-frame" sandbox="allow-scripts allow-same-origin allow-pointer-lock" allow="autoplay; fullscreen"></iframe>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // Event-Listener für Header-Controls
        document.getElementById('xera-btn-close').addEventListener('click', () => this.stopGame());
        document.getElementById('xera-btn-fullscreen').addEventListener('click', () => {
            const frame = document.getElementById('xera-game-frame');
            if (frame.requestFullscreen) frame.requestFullscreen();
        });
    },

    // Startet ein entpacktes Spiel aus den extrahierten Blob-Dateien
    async launchGame(gameData) {
        console.log(`[XERA Engine] Starte Spiel: ${gameData.name}`);
        const modal = document.getElementById('xera-game-modal');
        const frame = document.getElementById('xera-game-frame');
        const title = document.getElementById('xera-game-title');

        title.textContent = gameData.name;
        this.clearBlobURLs();

        // 1. Virtuelle Mappings für CSS, JS & Assets im Speicher erzeugen
        const urlMap = {};
        for (const [relativePath, blob] of Object.entries(gameData.files)) {
            const blobURL = URL.createObjectURL(blob);
            urlMap[relativePath] = blobURL;
            this.activeBlobURLs.push(blobURL);
        }

        // 2. Einstiegspunkt Codes/game_engine.html auslesen & verarbeiten
        const entryBlob = gameData.files['Codes/game_engine.html'];
        if (!entryBlob) {
            alert('Fehler: Codes/game_engine.html konnte nicht geladen werden!');
            return;
        }

        let htmlContent = await entryBlob.text();

        // 3. Pfad-Ersetzungen im HTML durchführen, damit Scripts, Styles & Assets die Blob-URLs finden
        for (const [relativePath, blobURL] of Object.entries(urlMap)) {
            // Relativpfade im Code anpassen (z.B. Styles/..., Assets/...)
            const regex = new RegExp(`(["'])(?:\\.\\/)?${relativePath.replace(/\//g, '\\/')}(["'])`, 'g');
            htmlContent = htmlContent.replace(regex, `$1${blobURL}$2`);
        }

        // 4. Finalen Bootstrap-Blob für den Iframe erzeugen und starten
        const finalHtmlBlob = new Blob([htmlContent], { type: 'text/html' });
        const finalEntryPoint = URL.createObjectURL(finalHtmlBlob);
        this.activeBlobURLs.push(finalEntryPoint);

        frame.src = finalEntryPoint;
        modal.style.display = 'flex';
    },

    // Spiel beenden und Speicher freigeben
    stopGame() {
        const modal = document.getElementById('xera-game-modal');
        const frame = document.getElementById('xera-game-frame');
        
        frame.src = 'about:blank';
        modal.style.display = 'none';
        this.clearBlobURLs();
        console.log('[XERA Engine] Spielinstanz beendet und Speicher bereinigt.');
    },

    clearBlobURLs() {
        this.activeBlobURLs.forEach(url => URL.revokeObjectURL(url));
        this.activeBlobURLs = [];
    }
};

document.addEventListener('DOMContentLoaded', () => {
    XeraEngine.init();
});
/* ==========================================================================
   XERA CORE ENGINE & ECONOMY RUNTIME (game_engine.js)
   Zentraler Game-Runner, State Management & Live-Token-Wirtschaft
   ========================================================================== */

const XeraEngine = {
    config: {
        appName: "XERA Gaming Hub",
        version: "1.0.0",
        defaultTokens: 5000000000000 // 5 Trillionen Tokens Standard
    },

    activeBlobURLs: [],

    init() {
        console.log(`[XERA Engine v${this.config.version}] System gestartet.`);
        this.checkTokenBalance();
        this.syncUIElements();
        this.injectGameViewportModal();
    },

    // Token-Guthaben aus dem localStorage abrufen (mit Initialisierung)
    checkTokenBalance() {
        let tokens = localStorage.getItem('xera_tokens');
        if (tokens === null) {
            tokens = this.config.defaultTokens;
            localStorage.setItem('xera_tokens', tokens);
        }
        return parseInt(tokens, 10);
    },

    // Tokens hinzufügen (z.B. durch Währungswechsel oder Belohnungen)
    addTokens(amount, sourceName = '') {
        let current = this.checkTokenBalance();
        current += amount;
        localStorage.setItem('xera_tokens', current);
        this.syncUIElements();
        alert(`Erfolg! ${amount.toLocaleString('de-DE')} Tokens hinzugefügt (${sourceName}).`);
    },

    // Tokens abziehen (z.B. beim Kauf von Spielen im Store)
    spendTokens(amount, itemName = '') {
        let current = this.checkTokenBalance();
        if (current < amount) {
            alert(`Fehler: Nicht genügend Tokens! Dir fehlen ${(amount - current).toLocaleString('de-DE')} Tokens.`);
            return false;
        }
        current -= amount;
        localStorage.setItem('xera_tokens', current);
        this.syncUIElements();
        alert(`Kauf erfolgreich! "${itemName}" wurde für ${amount.toLocaleString('de-DE')} Tokens erworben.`);
        return true;
    },

    // Synchronisiert alle Token-Anzeigen im DOM auf allen Seiten im Hub
    syncUIElements() {
        const currentTokens = this.checkTokenBalance();
        const formattedTokens = currentTokens.toLocaleString('de-DE') + " Tokens";

        // Alle bekannten Token-Displays aktualisieren
        document.querySelectorAll('.token-display strong, .token-large, #header-token-count, #main-token-count').forEach(el => {
            if (el.id === 'main-token-count') {
                el.textContent = "🪙 " + formattedTokens;
            } else if (el.id === 'header-token-count') {
                el.textContent = currentTokens.toLocaleString('de-DE');
            } else {
                el.textContent = formattedTokens;
            }
        });

        // Login-Status prüfen
        const isLoggedIn = localStorage.getItem('xera_is_logged_in') === 'true';
        const username = localStorage.getItem('xera_username') || "User_XERA";
        const userDisplay = document.getElementById('current-user');
        if (userDisplay) {
            userDisplay.textContent = username;
        }
    },

    // Injectet das große Spiele-Fenster (Modal/Overlay)
    injectGameViewportModal() {
        if (document.getElementById('xera-game-modal')) return;

        const modalHTML = `
            <div id="xera-game-modal" class="xera-game-modal" style="display: none;">
                <div class="xera-game-header">
                    <div class="game-info">
                        <span class="logo-icon">⚡</span>
                        <h3 id="xera-game-title">XERA Game Instance</h3>
                    </div>
                    <div class="game-controls">
                        <button id="xera-btn-fullscreen" class="btn-glow btn-small">🛈 Vollbild</button>
                        <button id="xera-btn-close" class="btn-danger btn-small">❌ Spiel Beenden</button>
                    </div>
                </div>
                <div class="xera-game-body">
                    <iframe id="xera-game-frame" sandbox="allow-scripts allow-same-origin allow-pointer-lock" allow="autoplay; fullscreen"></iframe>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHTML);

        document.getElementById('xera-btn-close').addEventListener('click', () => this.stopGame());
        document.getElementById('xera-btn-fullscreen').addEventListener('click', () => {
            const frame = document.getElementById('xera-game-frame');
            if (frame.requestFullscreen) frame.requestFullscreen();
        });
    },

    // Spiel starten via Blobs
    async launchGame(gameData) {
        const modal = document.getElementById('xera-game-modal');
        const frame = document.getElementById('xera-game-frame');
        const title = document.getElementById('xera-game-title');

        title.textContent = gameData.name;
        this.clearBlobURLs();

        const urlMap = {};
        for (const [relativePath, blob] of Object.entries(gameData.files)) {
            const blobURL = URL.createObjectURL(blob);
            urlMap[relativePath] = blobURL;
            this.activeBlobURLs.push(blobURL);
        }

        const entryBlob = gameData.files['Codes/game_engine.html'];
        if (!entryBlob) {
            alert('Fehler: Codes/game_engine.html nicht gefunden!');
            return;
        }

        let htmlContent = await entryBlob.text();
        for (const [relativePath, blobURL] of Object.entries(urlMap)) {
            const regex = new RegExp(`(["'])(?:\\.\\/)?${relativePath.replace(/\//g, '\\/')}(["'])`, 'g');
            htmlContent = htmlContent.replace(regex, `$1${blobURL}$2`);
        }

        const finalHtmlBlob = new Blob([htmlContent], { type: 'text/html' });
        const finalEntryPoint = URL.createObjectURL(finalHtmlBlob);
        this.activeBlobURLs.push(finalEntryPoint);

        frame.src = finalEntryPoint;
        modal.style.display = 'flex';
    },

    stopGame() {
        const modal = document.getElementById('xera-game-modal');
        const frame = document.getElementById('xera-game-frame');
        frame.src = 'about:blank';
        modal.style.display = 'none';
        this.clearBlobURLs();
    },

    clearBlobURLs() {
        this.activeBlobURLs.forEach(url => URL.revokeObjectURL(url));
        this.activeBlobURLs = [];
    },

    async hashPassword(password) {
        const msgBuffer = new TextEncoder().encode(password);
        const hashBuffer = await crypto.subtle.digest('SHA-512', msgBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }
};

document.addEventListener('DOMContentLoaded', () => {
    XeraEngine.init();
});
