document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const statusBox = document.getElementById('extraction-status');
    const statusText = document.getElementById('status-text');
    const statusPercent = document.getElementById('status-percent');
    const progressBarFill = document.getElementById('progress-bar-fill');

    // Drag-and-Drop Event Listener
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
        }, false);
    });

    dropZone.addEventListener('drop', (e) => {
        const files = e.dataTransfer.files;
        if (files.length > 0) handleGameZip(files[0]);
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) handleGameZip(e.target.files[0]);
    });

    // Hauptfunktion zum Extrahieren und Validieren
    async function handleGameZip(file) {
        if (!file.name.endsWith('.zip') && !file.name.endsWith('.xf')) {
            alert('Fehler: Nur .zip oder .xf Archive werden unterstützt!');
            return;
        }

        statusBox.style.display = 'block';
        statusText.textContent = `Analysiere ${file.name}...`;
        progressBarFill.style.width = '20%';
        statusPercent.textContent = '20%';

        try {
            const zip = new JSZip();
            const loadedZip = await zip.loadAsync(file);

            statusText.textContent = 'Prüfe Struktur (Codes/game_engine.html)...';
            progressBarFill.style.width = '50%';
            statusPercent.textContent = '50%';

            // Flexibles Finden von Codes/game_engine.html (falls ein Hauptordner im ZIP liegt)
            let entryPath = null;
            let allFiles = Object.keys(loadedZip.files);

            for (let path of allFiles) {
                if (path.endsWith('Codes/game_engine.html') || path === 'Codes/game_engine.html') {
                    entryPath = path;
                    break;
                }
            }

            // Strikte Validierung nach deiner Anforderung
            if (!entryPath) {
                throw new Error('Ungültiges Spiel-Format: "Codes/game_engine.html" wurde im Archiv nicht gefunden!');
            }

            // Basis-Pfad ermitteln (falls das ZIP noch einen Root-Ordner hat)
            const prefix = entryPath.replace('Codes/game_engine.html', '');
            
            statusText.textContent = 'Extrahiere Modul-Struktur (Codes, Styles, Assets)...';
            progressBarFill.style.width = '80%';
            statusPercent.textContent = '80%';

            // Dateien auslesen und im lokalen Speicher / Cache für den Launcher vorbereiten
            const gameData = {
                name: file.name.replace(/\.[^/.]+$/, ""),
                entryPoint: entryPath,
                files: {}
            };

            for (let relativePath of allFiles) {
                if (relativePath.startsWith(prefix) && !loadedZip.files[relativePath].dir) {
                    const cleanPath = relativePath.replace(prefix, '');
                    const fileData = await loadedZip.files[relativePath].async('blob');
                    gameData.files[cleanPath] = fileData;
                }
            }

            progressBarFill.style.width = '100%';
            statusPercent.textContent = '100%';
            statusText.textContent = 'Spiel erfolgreich validiert und extrahiert!';

            setTimeout(() => {
                alert(`Erfolg! Das Spiel "${gameData.name}" enthält den korrekten Einstiegspunkt und wurde der Bibliothek hinzugefügt.`);
                statusBox.style.display = 'none';
                progressBarFill.style.width = '0%';
                
                // Hier könnte das Spiel in localStorage oder IndexedDB gespeichert werden
            }, 600);

        } catch (err) {
            console.error(err);
            alert(`Import fehlgeschlagen: ${err.message}`);
            statusBox.style.display = 'none';
            progressBarFill.style.width = '0%';
        }
    }
});
// Nach erfolgreicher Entpackung in game_extractor.js:
XeraEngine.launchGame(gameData);
